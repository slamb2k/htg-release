#!/bin/bash

export DISPLAY=:0.0
export XAUTHORITY=/home/htc/.Xauthority

chromium-browser --no-first-run --disable --disable-translate --disable-infobars --disable-suggestions-service --disable-save-password-bubble --start-maximized --kiosk --disable-session-crashed-bubble --incognito $DISPLAY_URL
xdotool search --onlyvisible --class chromium-browser windowactivate key ctrl+r